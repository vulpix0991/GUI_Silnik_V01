# -*- coding: utf-8 -*-
import ast

def analiza_bezpieczna_wartosc(value_node):
    try:
        wartosc = ast.literal_eval(value_node)
        return repr(wartosc), False  # False = bezpieczna zmienna
    except Exception:
        try:
            kod = ast.unparse(value_node)
            return kod, True  # True = ryzykowna (funkcja, lambda itp.)
        except Exception:
            return "❌ nieznana wartość", True

def analizuj_zmienne_rekursywnie(node, prefix=""):
    zmienne = []

    if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef)):
        for child in getattr(node, "body", []):
            zmienne += analizuj_zmienne_rekursywnie(child, prefix)

    elif isinstance(node, (ast.Assign, ast.AnnAssign)):
        targets = node.targets if isinstance(node, ast.Assign) else [node.target]
        for target in targets:
            if isinstance(target, ast.Name):
                nazwa = prefix + target.id
                wartosc, ostrzezenie = analiza_bezpieczna_wartosc(node.value)
                zmienne.append((nazwa, wartosc, ostrzezenie))

            elif isinstance(target, ast.Tuple):
                if hasattr(node.value, "elts"):
                    for i, el in enumerate(target.elts):
                        if isinstance(el, ast.Name) and i < len(node.value.elts):
                            nazwa = prefix + el.id
                            wartosc, ostrzezenie = analiza_bezpieczna_wartosc(node.value.elts[i])
                            zmienne.append((nazwa, wartosc, ostrzezenie))

            elif isinstance(target, ast.Attribute):
                nazwa = prefix + ast.unparse(target)
                wartosc, ostrzezenie = analiza_bezpieczna_wartosc(node.value)
                zmienne.append((nazwa, wartosc, ostrzezenie))

    return zmienne

def analizuj_zmienne(kod):
    wynik = []
    try:
        drzewo = ast.parse(kod)
        wynik = analizuj_zmienne_rekursywnie(drzewo)
    except Exception as e:
        print(f"[ANALYZE ERROR] {e}")
    return wynik
