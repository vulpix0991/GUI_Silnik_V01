# -*- coding: utf-8 -*-
from .widget import WidgetJanuszedytor as Widget
from .widget import WidgetJanuszedytor
