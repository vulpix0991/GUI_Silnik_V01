# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import (
    QWidget, QLabel, QVBoxLayout, QPushButton, QFileDialog,
    QTableWidget, QTableWidgetItem, QMessageBox
)
from PyQt5.QtGui import QColor
from PyQt5.QtCore import Qt
import os
from .analyzer import analizuj_zmienne
from .saver import zapisz_zmienne

class WidgetJanuszedytor(QWidget):
    def __init__(self, settings=None):
        super().__init__()
        self.setObjectName("widget")
        self.plik_path = None
        self.zmienne = []

        self.layout = QVBoxLayout(self)
        self.label = QLabel("Janusz Edytor – wybierz plik Python")
        self.layout.addWidget(self.label)

        self.przycisk_wybierz = QPushButton("Wczytaj plik .py")
        self.przycisk_wybierz.clicked.connect(self.wczytaj_plik)
        self.layout.addWidget(self.przycisk_wybierz)

        self.tabela = QTableWidget(0, 2)
        self.tabela.setHorizontalHeaderLabels(["Zmienna", "Nowa wartość"])
        self.layout.addWidget(self.tabela)

        self.przycisk_zapisz = QPushButton("Zapisz zmiany")
        self.przycisk_zapisz.clicked.connect(self.zapisz)
        self.layout.addWidget(self.przycisk_zapisz)

    def wczytaj_plik(self):
        path, _ = QFileDialog.getOpenFileName(self, "Wybierz plik", "", "Pliki Python (*.py)")
        if not path:
            print(">>> [INFO] Nie wybrano pliku.")
            return

        print(f">>> [INFO] Wybrano plik: {path}")
        self.plik_path = path

        try:
            with open(path, "r", encoding="utf-8") as f:
                kod = f.read()
        except Exception as e:
            QMessageBox.critical(self, "Błąd", f"Nie można wczytać pliku:\n{e}")
            return

        self.zmienne = analizuj_zmienne(kod)
        print(f">>> [DEBUG] Znaleziono zmienne: {self.zmienne}")

        self.tabela.setRowCount(len(self.zmienne))
        self.tabela.clearContents()

        for i, (nazwa, wartosc, ostrzezenie) in enumerate(self.zmienne):
            nazwa_item = QTableWidgetItem(nazwa)
            wartosc_item = QTableWidgetItem(wartosc)

            if ostrzezenie:
                wartosc_item.setFlags(wartosc_item.flags() & ~Qt.ItemIsEditable)
                wartosc_item.setBackground(QColor(255, 200, 200))
                wartosc_item.setToolTip("Zmiana tej wartości może uszkodzić aplikację!")
            else:
                wartosc_item.setBackground(QColor(200, 255, 200))

            self.tabela.setItem(i, 0, nazwa_item)
            self.tabela.setItem(i, 1, wartosc_item)

        self.tabela.viewport().update()

    def zapisz(self):
        if not self.plik_path:
            return
        nowe = []
        for i, (nazwa, _, ostrzezenie) in enumerate(self.zmienne):
            wartosc_item = self.tabela.item(i, 1)
            wartosc = wartosc_item.text() if wartosc_item else ""
            nowe.append((nazwa, wartosc))

        try:
            zapisz_zmienne(self.plik_path, nowe)
            QMessageBox.information(self, "Sukces", "Zmieniono wartości zmiennych.")
        except Exception as e:
            QMessageBox.critical(self, "Błąd", str(e))

# Tryb podglądu
class Widget(QWidget):
    def __init__(self, settings=None):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Widżet: WidgetJanuszedytor (tryb podglądu)"))
