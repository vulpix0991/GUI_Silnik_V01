# -*- coding: utf-8 -*-
def zapisz_zmienne(sciezka, nowe_wartosci):
    """
    Zapisuje nowe wartości zmiennych w pliku .py tylko wtedy,
    gdy nie zawierają błędów lub znaczników ostrzegawczych ("❌").
    """
    try:
        with open(sciezka, "r", encoding="utf-8") as f:
            linie = f.readlines()
    except Exception as e:
        raise RuntimeError(f"Nie można odczytać pliku: {e}")

    for i, (nazwa, nowa_wartosc) in enumerate(nowe_wartosci):
        nowa_wartosc = nowa_wartosc.strip()

        # Pomijamy wartości oznaczone jako nieedytowalne
        if "❌" in nowa_wartosc or nowa_wartosc == "":
            continue

        # Nadpisujemy linię, która zaczyna się od nazwy zmiennej
        for j, linia in enumerate(linie):
            if linia.strip().startswith(f"{nazwa} ="):
                linie[j] = f"{nazwa} = {nowa_wartosc}\n"
                break

    try:
        with open(sciezka, "w", encoding="utf-8") as f:
            f.writelines(linie)
    except Exception as e:
        raise RuntimeError(f"Nie można zapisać zmian do pliku: {e}")
