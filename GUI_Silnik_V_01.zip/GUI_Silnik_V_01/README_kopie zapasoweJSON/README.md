
# 🧠 Silnik GUI PyQt – Modularna Baza Aplikacji

Ten projekt to elastyczny silnik aplikacji oparty na PyQt5, zaprojektowany tak, aby **żaden istniejący plik nigdy nie musiał być modyfikowany**. Nowe funkcje są dodawane wyłącznie poprzez **panel dodawania widżetów**, co czyni projekt niezwykle stabilnym, modularnym i łatwym w utrzymaniu.

---

## 📁 Struktura projektu

```
projekt/
├── main/               # Okno główne i uruchamianie (ZAMROŻONE)
├── core/               # Stylizacja, ładowanie styli (ZAMROŻONE)
├── config/             # Pliki konfiguracyjne (ZAMROŻONE)
├── widzety/            # Wszystkie widżety GUI
│   └── widget_xyz/     # Każdy widżet w osobnym folderze
├── run.py              # Start aplikacji
├── start.bat           # Uruchamianie z PowerShell + zależności
```

---

## 📌 Zasady nienaruszalności

Następujące pliki są **zamrożone i nie wolno ich modyfikować**:

- `main/okno_glowne.py`
- `main/loader.py`
- `core/style_applier.py`
- `config/settings.json` (edycja tylko przez GUI)
- `config/style_overrides.json` (edycja tylko przez GUI)
- `run.py`, `start.bat`
- `widzety/widget_ustawienia/` (ustawienia globalne)

---

## ➕ Dodawanie nowego widżetu

1. Uruchom aplikację.
2. Otwórz `panel_widgety`.
3. Podaj nazwę nowego widżetu i kliknij „Dodaj”.
4. W katalogu `widzety/` powstanie nowy folder z szablonem.
5. Edytuj pliki widżetu:
   - `gui.py` – interfejs użytkownika
   - `controller.py` – logika działania
   - inne moduły pomocnicze (np. `ai.py`, `tlumacz.py`)
6. Stylizuj przez `style_overrides.json` lub lokalnie (`setStyleSheet`).

---

## 🎨 Stylizacja

Style są definiowane w:
- `config/style_overrides.json`
- przez `core/style_applier.py`

Możesz stylizować typy komponentów:
```json
{
  "button": {"background": "ścieżka_do_obrazu.jpg"},
  "tag-label": {"font-size": 12, "color": "#ffffff"}
}
```

---

## 🌐 Integracja z AI / tłumaczeniami

Widżety mogą zawierać własne API (np. OpenAI):
- `openai_tags.py` – generowanie tagów przez API
- `tlumacz.py` – tłumaczenie offline (np. przez Argos Translate)

Wszystko trzymane lokalnie w folderze danego widżetu.

---

## 🧪 Testowanie widżetu

- Widżety są w pełni izolowane.
- Możesz testować je osobno, uruchamiając tylko GUI danego widżetu.
- Debuguj przez `print()` lub `logging` w konsoli.

---

## ✅ Przykładowy widżet

```
widzety/widget_przyklad/
├── gui.py             # QLabel i przycisk
├── controller.py      # Obsługa kliknięcia
├── style.json         # Lokalny styl
```

---

## 💡 Zasady jakości

- Kod zgodny z PEP8.
- Pliki zawsze UTF-8.
- Nazwy klas: `WidgetXxx`, nazwy plików: `widgetxxx.py`
- Bez zmiennych globalnych.
- Żadnych `eval`, `exec`.

---

## 📌 TODO (opcjonalne)

- Kreator promptów AI
- Pluginy z ZIP
- Edytory JSON
- Widżety do danych (CSV, obrazy, logi)

---

## 📦 Autorstwo i licencja

Stworzone jako elastyczny silnik aplikacji GUI przez użytkownika (Vulpix) z pomocą GPT.
