
# 🧠 PyQt GUIエンジン – モジュール式アプリケーションフレームワーク

このプロジェクトは PyQt5 をベースにした柔軟なアプリケーションエンジンです。  
特徴は **既存のファイルを一切変更せずに機能追加が可能** なこと。  
新しい機能はすべて **ウィジェット管理パネル** から追加されるため、安定性と拡張性に優れています。

---

## 📁 プロジェクト構成

```
project/
├── main/               # メインウィンドウと起動 (変更禁止)
├── core/               # スタイル適用・内部処理 (変更禁止)
├── config/             # 設定ファイル (JSON形式, 変更禁止)
├── widzety/            # GUIウィジェット群
│   └── widget_xyz/     # 各ウィジェットの専用フォルダ
├── run.py              # アプリ起動スクリプト
├── start.bat           # PowerShell起動＋依存関係
```

---

## 📌 保護されたファイル（変更禁止）

以下のファイルはシステムの中核であり、**絶対に変更してはいけません**：

- `main/okno_glowne.py`
- `main/loader.py`
- `core/style_applier.py`
- `config/settings.json`（GUIからのみ編集可能）
- `config/style_overrides.json`（GUIからのみ編集可能）
- `run.py`, `start.bat`
- `widzety/widget_ustawienia/`（アプリ全体の設定）

---

## ➕ ウィジェットの追加方法

1. アプリを起動します。
2. `panel_widgety` を開きます。
3. ウィジェット名を入力し、「追加」をクリック。
4. `widzety/` にテンプレート付きフォルダが作成されます。
5. 作成されたフォルダで次のファイルを編集：
   - `gui.py`：GUIの定義
   - `controller.py`：ロジック処理
   - 任意でヘルパーモジュール（例：`ai.py`, `tlumacz.py`）
6. スタイルは `style_overrides.json` または `setStyleSheet()` で調整。

---

## 🎨 スタイリング

スタイルは以下で定義：

- `config/style_overrides.json`
- `core/style_applier.py`

例：
```json
{
  "button": {"background": "path/to/image.jpg"},
  "tag-label": {"font-size": 12, "color": "#ffffff"}
}
```

---

## 🌐 AI・翻訳の統合

各ウィジェットは独自にAI APIを使用可能です（例：OpenAI）：

- `openai_tags.py`：タグ生成
- `tlumacz.py`：オフライン翻訳（例：Argos Translate）

すべての処理はウィジェット内に完結。

---

## 🧪 ウィジェットのテスト

- ウィジェットは完全に独立しており、個別にテスト可能。
- `print()` または `logging` でデバッグ。

---

## ✅ ウィジェットの例

```
widzety/widget_example/
├── gui.py             # QLabelとボタン
├── controller.py      # ボタン処理
├── style.json         # スタイル定義（任意）
```

---

## 💡 コーディングガイドライン

- PEP8に準拠。
- UTF-8を使用。
- クラス名：`WidgetXxx`、ファイル名：`widgetxxx.py`
- グローバル変数は禁止。
- `eval`, `exec` は使用禁止。

---

## 📌 TODO（今後追加予定）

- AIプロンプト生成機能
- ZIPプラグインシステム
- JSONエディター
- CSV・画像・ログ表示用ウィジェット

---

## 📦 クレジットとライセンス

本エンジンは、Vulpix氏とGPTの協力により設計されました。
