
# 🧠 PyQt GUI Engine – Modular Application Framework

This project is a flexible application engine based on PyQt5, designed so that **no existing file ever needs to be modified**. New features are added exclusively through the **widget management panel**, making the project extremely stable, modular, and easy to maintain.

---

## 📁 Project Structure

```
project/
├── main/               # Main window and launcher (FROZEN)
├── core/               # Styling engine and internals (FROZEN)
├── config/             # JSON configuration files (FROZEN)
├── widzety/            # All GUI widgets
│   └── widget_xyz/     # Each widget has its own folder
├── run.py              # App launcher
├── start.bat           # PowerShell startup with dependencies
```

---

## 📌 Frozen files and rules

The following files are **frozen and must never be modified**:

- `main/okno_glowne.py`
- `main/loader.py`
- `core/style_applier.py`
- `config/settings.json` (editable only via GUI)
- `config/style_overrides.json` (editable only via GUI)
- `run.py`, `start.bat`
- `widzety/widget_ustawienia/` (global settings)

---

## ➕ Adding a new widget

1. Launch the application.
2. Open the `panel_widgety`.
3. Enter the widget name and click "Add".
4. A new folder will be created in `widzety/` with a basic template.
5. Edit the widget files:
   - `gui.py` – user interface
   - `controller.py` – logic/controller
   - any helpers (e.g. `ai.py`, `tlumacz.py`)
6. Style via `style_overrides.json` or local `setStyleSheet`.

---

## 🎨 Styling System

Styles are defined in:
- `config/style_overrides.json`
- and applied via `core/style_applier.py`

Example component styles:
```json
{
  "button": {"background": "path/to/image.jpg"},
  "tag-label": {"font-size": 12, "color": "#ffffff"}
}
```

---

## 🌐 AI Integration / Translators

Widgets can use their own AI APIs (e.g. OpenAI):
- `openai_tags.py` – tag generation using OpenAI
- `tlumacz.py` – offline translation (e.g. Argos Translate)

All logic stays inside the widget folder.

---

## 🧪 Widget Testing

- Widgets are fully isolated.
- You can test each one independently.
- Use `print()` or `logging` for debugging in the console.

---

## ✅ Example Widget

```
widzety/widget_example/
├── gui.py             # QLabel and button
├── controller.py      # Button logic
├── style.json         # Optional local styles
```

---

## 💡 Code Quality Guidelines

- Follows PEP8.
- Always use UTF-8 encoding.
- Class names: `WidgetXxx`, file names: `widgetxxx.py`
- No global variables.
- No `eval`, `exec`.

---

## 📌 TODO (optional)

- AI Prompt Generator
- Plugin support from ZIP
- JSON editors
- Data widgets (CSV, images, logs)

---

## 📦 Authors and License

Created as a modular GUI app engine by user (Vulpix) with GPT assistance.
