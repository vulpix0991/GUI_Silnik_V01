# -*- coding: utf-8 -*-
import json
import os

from PyQt5.QtGui import QFontDatabase, QFont
from PyQt5.QtWidgets import QApplication


class Controller:
    def __init__(self):
        self.settings = self.load_settings()
        self.widget_lewy = None  # Referencja do lewego panelu (jeśli istnieje)

    def load_settings(self):
        try:
            with open("config/settings.json", "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"[WARN] Nie można wczytać settings.json: {e}")
            return {}

    def zapisz_ustawienia(self):
        try:
            os.makedirs("config", exist_ok=True)
            with open("config/settings.json", "w", encoding="utf-8") as f:
                json.dump(self.settings, f, indent=2, ensure_ascii=False)
            print("[INFO] Ustawienia zapisane.")
        except Exception as e:
            print(f"[BŁĄD] Nie udało się zapisać ustawień: {e}")

    def gui_ensure_sections(self):
        if "gui" not in self.settings:
            self.settings["gui"] = {}
        if "components" not in self.settings:
            self.settings["components"] = {}

    def gui_ustaw_font_size(self, value):
        self.gui_ensure_sections()
        self.settings["gui"]["font_size"] = value

    def gui_ustaw_font_path(self, path):
        self.gui_ensure_sections()
        if path and not os.path.exists(path):
            print(f"[WARN] Ścieżka fontu nie istnieje: {path}")
        self.settings["gui"]["font_path"] = path

    def gui_ustaw_scale_widgets(self, value):
        self.gui_ensure_sections()
        self.settings["gui"]["scale_widgets"] = value

    def gui_ustaw_scale_fonts(self, value):
        self.gui_ensure_sections()
        self.settings["gui"]["scale_fonts"] = value

    def gui_ustaw_padding(self, value):
        self.gui_ensure_sections()
        self.settings["gui"]["padding"] = value

    def gui_ustaw_button_spacing(self, value):
        self.gui_ensure_sections()
        self.settings["gui"]["button_spacing"] = value

    def gui_ustaw_parametr_komponentu(self, komponent, parametr, wartosc):
        self.gui_ensure_sections()
        if komponent not in self.settings["components"]:
            self.settings["components"][komponent] = {}
        self.settings["components"][komponent][parametr] = wartosc

    def gui_ustaw_tlo_komponentu(self, komponent, path):
        self.gui_ensure_sections()
        if path and not os.path.exists(path):
            print(f"[WARN] Ścieżka tła nie istnieje: {path}")
        if komponent not in self.settings["components"]:
            self.settings["components"][komponent] = {}
        self.settings["components"][komponent]["background"] = path

    def odswiez_widget_lewy(self):
        if self.widget_lewy:
            self.widget_lewy.odswiez()
        else:
            print("[INFO] Brak referencji do widget_lewy – odświeżenie pominięte.")


# BEGIN: instancja kontrolera
controller = Controller()
# END: instancja kontrolera


# BEGIN: GLOBALNE USTAWIENIA APLIKACJI
def zastosuj_ustawienia_globalne():
    font_size = controller.settings.get("gui", {}).get("font_size", 10)
    font_path = controller.settings.get("gui", {}).get("font_path", "")

    if font_path and os.path.exists(font_path):
        QFontDatabase.addApplicationFont(font_path)
        font_family = QFontDatabase.applicationFontFamilies(0)[0]
        font = QFont(font_family, font_size)
    else:
        font = QFont()
        font.setPointSize(font_size)

    QApplication.setFont(font)
# END: GLOBALNE USTAWIENIA APLIKACJI
