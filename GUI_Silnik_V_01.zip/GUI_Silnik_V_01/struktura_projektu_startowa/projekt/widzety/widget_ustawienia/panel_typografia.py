# -*- coding: utf-8 -*-
# projekt/widzety/widget_ustawienia/panel_typografia.py

from PyQt5.QtWidgets import (
    QWidget, QLabel, QVBoxLayout, QHBoxLayout,
    QLineEdit, QPushButton, QFileDialog
)
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QSpinBox, QDoubleSpinBox
from widzety.widget_ustawienia.controller import controller


class PanelTypografia(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(15, 15, 15, 15)

        # BEGIN: Ścieżka czcionki
        layout.addLayout(self.stworz_sekcje_tla(
            label="Plik czcionki (.ttf):",
            key_path=["gui", "font_path"],
            komponent_label="label",
            komponent_input="textfield",
            komponent_button="button",
            filtr="Czcionki (*.ttf)"
        ))
        # END

        # BEGIN: Typografia GUI
        layout.addLayout(self.stworz_spinbox(
            label="Bazowy rozmiar czcionki (pt):",
            key_path=["gui", "font_size"],
            min_val=6, max_val=64
        ))

        layout.addLayout(self.stworz_spinbox(
            label="Powiększenie czcionki (x):",
            key_path=["gui", "scale_fonts"],
            min_val=0.5, max_val=3.0,
            step=0.1,
            float_mode=True
        ))

        layout.addLayout(self.stworz_spinbox(
            label="Skalowanie elementów (x):",
            key_path=["gui", "scale_widgets"],
            min_val=0.5, max_val=3.0,
            step=0.1,
            float_mode=True
        ))

        layout.addLayout(self.stworz_spinbox(
            label="Odstęp wewnętrzny (padding):",
            key_path=["gui", "padding"],
            min_val=0, max_val=100
        ))

        layout.addLayout(self.stworz_spinbox(
            label="Odstęp między przyciskami (spacing):",
            key_path=["gui", "button_spacing"],
            min_val=0, max_val=100
        ))
        # END

        layout.addStretch()

        # Styl panelu
        try:
            from core.style_applier import apply_component_styles
            apply_component_styles(self, "panel")
        except Exception as e:
            print(f"[WARN] Styl panelu typografia: {e}")

    def stworz_sekcje_tla(self, label, key_path, komponent_label, komponent_input, komponent_button, filtr="Pliki (*)"):
        hbox = QHBoxLayout()
        hbox.setSpacing(10)

        etykieta = QLabel(label)
        input_pole = QLineEdit()
        input_pole.setReadOnly(True)

        ustawienia = controller.settings
        for k in key_path[:-1]:
            ustawienia = ustawienia.setdefault(k, {})
        aktualna = ustawienia.get(key_path[-1], "")
        input_pole.setText(str(aktualna))

        przycisk = QPushButton("Wybierz")
        przycisk.clicked.connect(lambda: self.wybierz_plik(input_pole, key_path, filtr))

        hbox.addWidget(etykieta)
        hbox.addWidget(input_pole)
        hbox.addWidget(przycisk)

        try:
            from core.style_applier import apply_component_styles
            apply_component_styles(etykieta, komponent_label)
            apply_component_styles(input_pole, komponent_input)
            apply_component_styles(przycisk, komponent_button)
        except Exception as e:
            print(f"[WARN] Styl ścieżki '{label}': {e}")

        return hbox

    def stworz_spinbox(self, label, key_path, min_val, max_val, step=1, float_mode=False):
        hbox = QHBoxLayout()
        hbox.setSpacing(10)

        etykieta = QLabel(label)

        if float_mode:
            spinbox = QDoubleSpinBox()
            spinbox.setDecimals(2)
        else:
            spinbox = QSpinBox()

        spinbox.setRange(min_val, max_val)
        spinbox.setSingleStep(step)

        ustawienia = controller.settings
        for k in key_path[:-1]:
            ustawienia = ustawienia.setdefault(k, {})
        wartosc = ustawienia.get(key_path[-1], min_val)
        spinbox.setValue(float(wartosc) if float_mode else int(wartosc))

        def on_change(val):
            ustawienia = controller.settings
            for k in key_path[:-1]:
                ustawienia = ustawienia.setdefault(k, {})
            ustawienia[key_path[-1]] = float(val) if float_mode else int(val)

        spinbox.valueChanged.connect(on_change)

        hbox.addWidget(etykieta)
        hbox.addWidget(spinbox)

        try:
            from core.style_applier import apply_component_styles
            apply_component_styles(etykieta, "label")
            apply_component_styles(spinbox, "textfield")
        except Exception as e:
            print(f"[WARN] Styl spinboxa '{label}': {e}")

        return hbox

    def wybierz_plik(self, input_widget, key_path, filtr):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Wybierz plik", "", filtr
        )
        if file_path:
            input_widget.setText(file_path)
            ustawienia = controller.settings
            for k in key_path[:-1]:
                ustawienia = ustawienia.setdefault(k, {})
            ustawienia[key_path[-1]] = file_path
