# -*- coding: utf-8 -*-
# projekt/widzety/widget_ustawienia/panel_okno.py

from PyQt5.QtWidgets import (
    QWidget, QLabel, QVBoxLayout, QHBoxLayout,
    QSpinBox, QCheckBox
)
from PyQt5.QtCore import Qt
from widzety.widget_ustawienia.controller import controller


class PanelOkno(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(15, 15, 15, 15)

        # BEGIN: Rozmiar okna
        layout.addLayout(self.stworz_spinbox(
            label="Szerokość okna (px):",
            key_path=["window", "width"],
            min_val=400, max_val=3840,
            tooltip="np. 1280"
        ))

        layout.addLayout(self.stworz_spinbox(
            label="Wysokość okna (px):",
            key_path=["window", "height"],
            min_val=300, max_val=2160,
            tooltip="np. 720"
        ))
        # END

        # BEGIN: Fullscreen
        layout.addLayout(self.stworz_checkbox(
            label="Tryb pełnoekranowy:",
            key_path=["window", "fullscreen"]
        ))
        # END

        # BEGIN: Resizable
        layout.addLayout(self.stworz_checkbox(
            label="Czy można zmieniać rozmiar okna (resizable):",
            key_path=["window", "resizable"]
        ))
        # END

        layout.addStretch()

        # Styl panelu
        try:
            from core.style_applier import apply_component_styles
            apply_component_styles(self, "panel")
        except Exception as e:
            print(f"[WARN] Styl panelu okno: {e}")

    def stworz_spinbox(self, label, key_path, min_val=400, max_val=3840, step=10, tooltip=""):
        hbox = QHBoxLayout()
        hbox.setSpacing(10)

        etykieta = QLabel(label)
        spinbox = QSpinBox()
        spinbox.setRange(min_val, max_val)
        spinbox.setSingleStep(step)
        if tooltip:
            spinbox.setToolTip(tooltip)

        ustawienia = controller.settings
        for k in key_path[:-1]:
            ustawienia = ustawienia.setdefault(k, {})
        wartosc = ustawienia.get(key_path[-1], min_val)
        spinbox.setValue(int(wartosc))

        def on_change(val):
            ustawienia = controller.settings
            for k in key_path[:-1]:
                ustawienia = ustawienia.setdefault(k, {})
            ustawienia[key_path[-1]] = int(val)

        spinbox.valueChanged.connect(on_change)

        hbox.addWidget(etykieta)
        hbox.addWidget(spinbox)

        try:
            from core.style_applier import apply_component_styles
            apply_component_styles(etykieta, "label")
            apply_component_styles(spinbox, "textfield")
        except Exception as e:
            print(f"[WARN] Styl spinboxa '{label}': {e}")

        return hbox

    def stworz_checkbox(self, label, key_path):
        hbox = QHBoxLayout()
        hbox.setSpacing(10)

        etykieta = QLabel(label)
        checkbox = QCheckBox()

        ustawienia = controller.settings
        for k in key_path[:-1]:
            ustawienia = ustawienia.setdefault(k, {})
        checkbox.setChecked(bool(ustawienia.get(key_path[-1], False)))

        def on_toggle(state):
            ustawienia = controller.settings
            for k in key_path[:-1]:
                ustawienia = ustawienia.setdefault(k, {})
            ustawienia[key_path[-1]] = (state == Qt.Checked)

        checkbox.stateChanged.connect(on_toggle)

        hbox.addWidget(etykieta)
        hbox.addWidget(checkbox)

        try:
            from core.style_applier import apply_component_styles
            apply_component_styles(etykieta, "label")
            apply_component_styles(checkbox, "checkbox")
        except Exception as e:
            print(f"[WARN] Styl checkboxa '{label}': {e}")

        return hbox
