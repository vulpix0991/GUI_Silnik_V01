# -*- coding: utf-8 -*-
# projekt/widzety/widget_ustawienia/panel_elementy.py

from PyQt5.QtWidgets import (
    QWidget, QLabel, QVBoxLayout, QHBoxLayout,
    QPushButton, QLineEdit, QSpinBox, QCheckBox, QFileDialog
)
from PyQt5.QtCore import Qt
from widzety.widget_ustawienia.controller import controller


class PanelElementy(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(15, 15, 15, 15)

        # BEGIN: Rozmiary komponentów
        layout.addLayout(self.stworz_spinbox(
            label="Szerokość przycisku:",
            key_path=["components", "button", "width"],
            min_val=40, max_val=600
        ))

        layout.addLayout(self.stworz_spinbox(
            label="Wysokość przycisku:",
            key_path=["components", "button", "height"],
            min_val=20, max_val=300
        ))

        layout.addLayout(self.stworz_spinbox(
            label="Padding przycisków:",
            key_path=["components", "button", "padding"],
            min_val=0, max_val=100
        ))

        layout.addLayout(self.stworz_spinbox(
            label="Margines przycisków:",
            key_path=["components", "button", "margin"],
            min_val=0, max_val=100
        ))

        layout.addLayout(self.stworz_spinbox(
            label="Wysokość etykiety (label):",
            key_path=["components", "label", "height"],
            min_val=10, max_val=300
        ))
        # END

        # BEGIN: Czcionki komponentów podstawowych
        layout.addLayout(self.stworz_spinbox(
            label="Czcionka pola tekstowego (lineedit):",
            key_path=["components", "lineedit", "font_size"],
            min_val=6, max_val=48
        ))

        layout.addLayout(self.stworz_spinbox(
            label="Czcionka listy wyboru (combobox):",
            key_path=["components", "combobox", "font_size"],
            min_val=6, max_val=48
        ))

        layout.addLayout(self.stworz_spinbox(
            label="Czcionka opcji (radiobutton):",
            key_path=["components", "radiobutton", "font_size"],
            min_val=6, max_val=48
        ))

        layout.addLayout(self.stworz_spinbox(
            label="Czcionka przełączników (checkbox):",
            key_path=["components", "checkbox", "font_size"],
            min_val=6, max_val=48
        ))
        # END

        # BEGIN: Czcionki komponentów dodatkowych
        layout.addLayout(self.stworz_spinbox(
            label="Czcionka etykiety (label):",
            key_path=["components", "label", "font_size"],
            min_val=6, max_val=48
        ))

        layout.addLayout(self.stworz_spinbox(
            label="Czcionka menu tekstowego (menu_text):",
            key_path=["components", "menu_text", "font_size"],
            min_val=6, max_val=48
        ))

        layout.addLayout(self.stworz_spinbox(
            label="Czcionka pola tekstowego (textfield):",
            key_path=["components", "textfield", "font_size"],
            min_val=6, max_val=48
        ))

        layout.addLayout(self.stworz_spinbox(
            label="Czcionka obszaru przewijania (scrollarea):",
            key_path=["components", "scrollarea", "font_size"],
            min_val=6, max_val=48
        ))

        layout.addLayout(self.stworz_spinbox(
            label="Czcionka ramki (frame):",
            key_path=["components", "frame", "font_size"],
            min_val=6, max_val=48
        ))
        # END

        layout.addStretch()

        # Styl panelu
        try:
            from core.style_applier import apply_component_styles
            apply_component_styles(self, "panel")
        except Exception as e:
            print(f"[WARN] Styl panelu elementy: {e}")

    def stworz_spinbox(self, label, key_path, min_val, max_val, step=1, float_mode=False):
        hbox = QHBoxLayout()
        hbox.setSpacing(10)

        etykieta = QLabel(label)

        if float_mode:
            from PyQt5.QtWidgets import QDoubleSpinBox
            spinbox = QDoubleSpinBox()
            spinbox.setDecimals(2)
        else:
            spinbox = QSpinBox()

        spinbox.setRange(min_val, max_val)
        spinbox.setSingleStep(step)

        ustawienia = controller.settings
        for k in key_path[:-1]:
            ustawienia = ustawienia.setdefault(k, {})
        wartosc = ustawienia.get(key_path[-1], min_val)
        spinbox.setValue(float(wartosc) if float_mode else int(wartosc))

        def on_change(val):
            ustawienia = controller.settings
            for k in key_path[:-1]:
                ustawienia = ustawienia.setdefault(k, {})
            ustawienia[key_path[-1]] = float(val) if float_mode else int(val)

        spinbox.valueChanged.connect(on_change)

        hbox.addWidget(etykieta)
        hbox.addWidget(spinbox)

        try:
            from core.style_applier import apply_component_styles
            apply_component_styles(etykieta, "label")
            apply_component_styles(spinbox, "textfield")
        except Exception as e:
            print(f"[WARN] Styl spinboxa '{label}': {e}")

        return hbox
