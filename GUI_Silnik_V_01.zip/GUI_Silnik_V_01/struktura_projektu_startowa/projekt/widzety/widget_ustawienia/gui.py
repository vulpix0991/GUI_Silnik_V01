# -*- coding: utf-8 -*-
# obecnie nieużywane – GUI budowany w __init__.py
