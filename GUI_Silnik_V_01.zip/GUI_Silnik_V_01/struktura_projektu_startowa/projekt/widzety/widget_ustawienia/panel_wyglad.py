# -*- coding: utf-8 -*-
# projekt/widzety/widget_ustawienia/panel_wyglad.py

import os
from PyQt5.QtWidgets import (
    QWidget, QLabel, QVBoxLayout, QHBoxLayout,
    QPushButton, QLineEdit, QFileDialog
)
from PyQt5.QtCore import Qt
from widzety.widget_ustawienia.controller import controller


class PanelWyglad(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setSpacing(15)
        layout.setContentsMargins(15, 15, 15, 15)

        # BEGIN: Tło aplikacji
        layout.addLayout(self.stworz_sekcje_tla(
            label="Tło aplikacji (okna głównego):",
            key_path=["window", "background_image"],
            komponent_label="label",
            komponent_input="textfield",
            komponent_button="button"
        ))
        # END

        # BEGIN: Tła komponentów
        layout.addLayout(self.stworz_sekcje_tla(
            label="Tło przycisku:",
            key_path=["components", "button", "background"],
            komponent_label="label",
            komponent_input="textfield",
            komponent_button="button"
        ))

        layout.addLayout(self.stworz_sekcje_tla(
            label="Tło pola tekstowego (textfield):",
            key_path=["components", "textfield", "background"],
            komponent_label="label",
            komponent_input="textfield",
            komponent_button="button"
        ))

        layout.addLayout(self.stworz_sekcje_tla(
            label="Tło etykiety (label):",
            key_path=["components", "label", "background"],
            komponent_label="label",
            komponent_input="textfield",
            komponent_button="button"
        ))

        layout.addLayout(self.stworz_sekcje_tla(
            label="Tło pola edycji (lineedit):",
            key_path=["components", "lineedit", "background"],
            komponent_label="label",
            komponent_input="textfield",
            komponent_button="button"
        ))

        layout.addLayout(self.stworz_sekcje_tla(
            label="Tło menu tekstowego:",
            key_path=["components", "menu_text", "background"],
            komponent_label="label",
            komponent_input="textfield",
            komponent_button="button"
        ))

        layout.addLayout(self.stworz_sekcje_tla(
            label="Tło obszaru przewijania (scrollarea):",
            key_path=["components", "scrollarea", "background"],
            komponent_label="label",
            komponent_input="textfield",
            komponent_button="button"
        ))

        layout.addLayout(self.stworz_sekcje_tla(
            label="Tło ramki (frame):",
            key_path=["components", "frame", "background"],
            komponent_label="label",
            komponent_input="textfield",
            komponent_button="button"
        ))

        layout.addLayout(self.stworz_sekcje_tla(
            label="Tło listy wyboru (combobox):",
            key_path=["components", "combobox", "background"],
            komponent_label="label",
            komponent_input="textfield",
            komponent_button="button"
        ))
        # END

        layout.addStretch()

        # Styl panelu
        try:
            from core.style_applier import apply_component_styles
            apply_component_styles(self, "panel")
        except Exception as e:
            print(f"[WARN] Styl panelu wygląd: {e}")

    def stworz_sekcje_tla(self, label, key_path, komponent_label, komponent_input, komponent_button,
                          filtr="Obrazy (*.png *.jpg *.jpeg *.bmp *.gif)"):
        hbox = QHBoxLayout()
        hbox.setSpacing(10)

        etykieta = QLabel(label)
        input_pole = QLineEdit()
        input_pole.setReadOnly(True)

        ustawienia = controller.settings
        for k in key_path[:-1]:
            ustawienia = ustawienia.setdefault(k, {})
        aktualna = ustawienia.get(key_path[-1], "")
        input_pole.setText(str(aktualna))

        przycisk = QPushButton("Wybierz")
        przycisk.clicked.connect(lambda: self.wybierz_plik(input_pole, key_path, filtr))

        hbox.addWidget(etykieta)
        hbox.addWidget(input_pole)
        hbox.addWidget(przycisk)

        try:
            from core.style_applier import apply_component_styles
            apply_component_styles(etykieta, komponent_label)
            apply_component_styles(input_pole, komponent_input)
            apply_component_styles(przycisk, komponent_button)
        except Exception as e:
            print(f"[WARN] Styl ścieżki '{label}': {e}")

        return hbox

    def wybierz_plik(self, input_widget, key_path, filtr):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Wybierz plik graficzny", "style", filtr
        )
        if file_path and os.path.exists(file_path):
            input_widget.setText(file_path)
            ustawienia = controller.settings
            for k in key_path[:-1]:
                ustawienia = ustawienia.setdefault(k, {})
            ustawienia[key_path[-1]] = file_path
