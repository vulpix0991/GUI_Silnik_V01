# -*- coding: utf-8 -*-
# projekt/widzety/widget_ustawienia/__init__.py

from PyQt5.QtWidgets import QWidget, QTabWidget, QVBoxLayout, QPushButton
from widzety.widget_ustawienia import (
    panel_okno,
    panel_wyglad,
    panel_typografia,
    panel_elementy,
    panel_widgety,
)
from widzety.widget_ustawienia.controller import controller


class WidgetUstawienia(QWidget):
    def __init__(self):
        super().__init__()
        print(">>> Tworzę WidgetUstawienia")  # TEST: potwierdzenie załadowania widżetu

        layout = QVBoxLayout(self)

        self.tabs = QTabWidget()
        self.tabs.addTab(panel_okno.PanelOkno(), "🪟 Okno")
        self.tabs.addTab(panel_wyglad.PanelWyglad(), "🎨 Wygląd")
        self.tabs.addTab(panel_typografia.PanelTypografia(), "🔠 Typografia")
        self.tabs.addTab(panel_elementy.PanelElementy(), "⚙️ Komponenty")
        self.tabs.addTab(panel_widgety.PanelWidgety(), "🧩 Widżety")

        layout.addWidget(self.tabs)

        self.save_button = QPushButton("💾 Zapisz ustawienia")
        self.save_button.clicked.connect(controller.zapisz_ustawienia)

        # BEGIN: Stylizacja przycisku zapisu
        try:
            from core.style_applier import apply_component_styles
            apply_component_styles(self.save_button, "button")
        except Exception as e:
            print(f"[WARN] Stylizacja zapisu: {e}")
        # END

        layout.addWidget(self.save_button)
