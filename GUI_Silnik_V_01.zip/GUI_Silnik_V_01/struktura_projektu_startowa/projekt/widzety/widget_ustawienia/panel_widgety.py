# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import (
    QWidget, QLabel, QPushButton, QVBoxLayout,
    QLineEdit, QListWidget, QMessageBox, QTextEdit
)
from PyQt5.QtCore import Qt
import os
import json
import shutil

from widzety.widget_ustawienia.controller import controller


class PanelWidgety(QWidget):
    def __init__(self):
        super().__init__()

        self.setObjectName("panel")
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(15, 15, 15, 15)

        self.etykieta_info = QLabel("Zarządzanie widżetami")
        self.etykieta_info.setAlignment(Qt.AlignCenter)

        self.input_nazwa = QLineEdit()
        self.input_nazwa.setPlaceholderText("Nowy widżet (bez rozszerzenia)")
        self.przycisk_dodaj = QPushButton("Dodaj widżet")
        self.przycisk_usun = QPushButton("Usuń zaznaczony widżet")
        self.przycisk_podglad = QPushButton("Podgląd opisu")
        self.lista_widgetow = QListWidget()

        self.przycisk_dodaj.clicked.connect(self.dodaj_widget)
        self.przycisk_usun.clicked.connect(self.usun_widget)
        self.przycisk_podglad.clicked.connect(self.pokaz_opis)

        self.layout.addWidget(self.etykieta_info)
        self.layout.addWidget(self.input_nazwa)
        self.layout.addWidget(self.przycisk_dodaj)
        self.layout.addWidget(self.lista_widgetow)
        self.layout.addWidget(self.przycisk_podglad)
        self.layout.addWidget(self.przycisk_usun)
        self.layout.addStretch()

        self.odswiez_liste_widgetow()

        try:
            from core.style_applier import apply_component_styles
            apply_component_styles(self, "panel")
            apply_component_styles(self.etykieta_info, "label")
            apply_component_styles(self.input_nazwa, "textfield")
            apply_component_styles(self.przycisk_dodaj, "button")
            apply_component_styles(self.przycisk_usun, "button")
            apply_component_styles(self.przycisk_podglad, "button")
        except Exception as e:
            print(f"[STYLE WARNING] {e}")

    def odswiez_liste_widgetow(self):
        self.lista_widgetow.clear()
        sciezka = os.path.join("config", "widgets.json")
        if os.path.exists(sciezka):
            with open(sciezka, "r", encoding="utf-8") as f:
                dane = json.load(f)
                for w in dane:
                    modul = w.get("module", "")
                    klasa = w.get("class", "")
                    self.lista_widgetow.addItem(f"{klasa} ({modul})")

    def dodaj_widget(self):
        nazwa = self.input_nazwa.text().strip()
        if not nazwa.isidentifier():
            QMessageBox.warning(self, "Błąd", "Niepoprawna nazwa widżetu.")
            return

        folder = os.path.join("widzety", nazwa.lower())
        plik = os.path.join(folder, "__init__.py")
        info_plik = os.path.join(folder, "info.txt")
        klasa = f"Widget{nazwa.capitalize()}"

        if os.path.exists(folder):
            QMessageBox.warning(self, "Istnieje", "Taki widżet już istnieje.")
            return

        try:
            os.makedirs(folder, exist_ok=True)
            with open(plik, "w", encoding="utf-8") as f:
                f.write(self.szablon_widgeta(nazwa.lower(), klasa))
            with open(info_plik, "w", encoding="utf-8") as f:
                f.write(f"Opis widżetu {klasa}...\n(Tutaj wpisz informacje o widżecie)")

            self.dodaj_do_widgets_json(nazwa.lower(), klasa)
            self.dodaj_do_menu_json(nazwa.lower())
            self.odswiez_liste_widgetow()
            QMessageBox.information(self, "Sukces", "Widżet dodany.")
        except Exception as e:
            QMessageBox.critical(self, "Błąd", str(e))

    def usun_widget(self):
        wybor = self.lista_widgetow.currentItem()
        if not wybor:
            return

        tekst = wybor.text()
        if "(" not in tekst:
            return

        klasa, modul = tekst.split("(", 1)
        klasa = klasa.strip()
        modul = modul.replace(")", "").strip()

        potwierdzenie = QMessageBox.question(
            self, "Potwierdzenie",
            f"Czy na pewno usunąć widżet '{klasa}'?"
        )
        if potwierdzenie != QMessageBox.Yes:
            return

        try:
            self.usun_z_widgets_json(modul)
            self.usun_z_menu_json(modul)

            folder = os.path.join("widzety", modul)
            if os.path.isdir(folder) and os.path.commonprefix([os.path.abspath(folder), os.path.abspath("widzety")]) == os.path.abspath("widzety"):
                shutil.rmtree(folder)

            self.odswiez_liste_widgetow()
        except Exception as e:
            QMessageBox.critical(self, "Błąd", str(e))

    def pokaz_opis(self):
        wybor = self.lista_widgetow.currentItem()
        if not wybor:
            return

        tekst = wybor.text()
        if "(" not in tekst:
            return

        _, modul = tekst.split("(", 1)
        modul = modul.replace(")", "").strip()

        sciezka = os.path.join("widzety", modul, "info.txt")
        if not os.path.exists(sciezka):
            QMessageBox.information(self, "Brak", "Brak pliku opisu.")
            return

        with open(sciezka, "r", encoding="utf-8") as f:
            tresc = f.read()

        okno = QMessageBox(self)
        okno.setWindowTitle(f"Opis: {modul}")
        okno.setText(tresc)
        okno.exec_()

    def dodaj_do_widgets_json(self, modul, klasa):
        sciezka = os.path.join("config", "widgets.json")
        dane = []
        if os.path.exists(sciezka):
            with open(sciezka, "r", encoding="utf-8") as f:
                dane = json.load(f)

        dane.append({
            "module": modul.lower(),
            "class": klasa,
            "position": "center"
        })
        with open(sciezka, "w", encoding="utf-8") as f:
            json.dump(dane, f, indent=4, ensure_ascii=False)

    def usun_z_widgets_json(self, modul):
        sciezka = os.path.join("config", "widgets.json")
        if not os.path.exists(sciezka):
            return
        with open(sciezka, "r", encoding="utf-8") as f:
            dane = json.load(f)
        dane = [w for w in dane if w.get("module") != modul]
        with open(sciezka, "w", encoding="utf-8") as f:
            json.dump(dane, f, indent=4, ensure_ascii=False)

    def dodaj_do_menu_json(self, modul):
        sciezka = os.path.join("config", "menu.json")
        dane = []
        if os.path.exists(sciezka):
            with open(sciezka, "r", encoding="utf-8") as f:
                dane = json.load(f)
        dane.append({
            "label": modul.capitalize(),
            "target_widget": modul.lower()
        })
        with open(sciezka, "w", encoding="utf-8") as f:
            json.dump(dane, f, indent=4, ensure_ascii=False)

    def usun_z_menu_json(self, modul):
        sciezka = os.path.join("config", "menu.json")
        if not os.path.exists(sciezka):
            return
        with open(sciezka, "r", encoding="utf-8") as f:
            dane = json.load(f)
        dane = [w for w in dane if w.get("target_widget") != modul]
        with open(sciezka, "w", encoding="utf-8") as f:
            json.dump(dane, f, indent=4, ensure_ascii=False)

    def szablon_widgeta(self, modul, klasa):
        return f'''# -*- coding: utf-8 -*-
from PyQt5.QtWidgets import QWidget, QLabel, QVBoxLayout

class Widget(QWidget):
    def __init__(self, settings=None):
        super().__init__()
        self.setObjectName("widget")
        layout = QVBoxLayout(self)
        label = QLabel("Widżet: {klasa}")
        layout.addWidget(label)

        try:
            from core.style_applier import apply_component_styles
            apply_component_styles(self, "widget")
            apply_component_styles(label, "label")
        except Exception as e:
            print(f"[STYLE WARNING] {{e}}")
'''
