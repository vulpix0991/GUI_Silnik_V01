# -*- coding: utf-8 -*-
# projekt/widzety/widget_lewy.py

import os
import json
from PyQt5.QtWidgets import QWidget, QPushButton, QVBoxLayout, QLabel
from PyQt5.QtCore import Qt

from core.style_applier import apply_component_styles  # Dodane do stylizacji

class WidgetMenu(QWidget):
    def __init__(self):
        super().__init__()
        self.callback = None
        self.settings = self.load_settings()
        self.scale = self.settings.get("gui", {}).get("scale_widgets", 1.0)
        self.font_size = self.settings.get("gui", {}).get("font_size", 12)
        self.padding = self.settings.get("gui", {}).get("padding", 0)
        self.spacing = self.settings.get("gui", {}).get("button_spacing", 10)

        self.layout = QVBoxLayout()
        self.layout.setSpacing(int(self.spacing))
        self.layout.setContentsMargins(
            self.padding, self.padding, self.padding, self.padding
        )
        self.setLayout(self.layout)

        self.load_menu_buttons()

        # BEGIN: Nakładanie stylu komponentu menu
        apply_component_styles(self, "menu")
        # END: Nakładanie stylu komponentu menu

    def set_callback(self, fn):
        self.callback = fn

    def load_settings(self):
        try:
            with open("config/settings.json", "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"[WARN] Nie można wczytać ustawień: {e}")
            return {}

    def load_menu_buttons(self):
        try:
            with open("config/menu.json", "r", encoding="utf-8") as f:
                menu_data = json.load(f)
        except Exception as e:
            print(f"[WARN] Nie można wczytać menu.json: {e}")
            label = QLabel("❌ Brak menu")
            self.layout.addWidget(label)
            return

        for item in menu_data:
            label = item.get("label", "Brak etykiety")
            target = item.get("target_widget")
            action = item.get("action")

            button = QPushButton(label)
            # BEGIN: poprawiony styl przycisku
            button.setMinimumHeight(int(22 * self.scale))
            button.setStyleSheet(
                f"""
                font-size: {int(self.font_size * self.scale)}pt;
                margin: 0px;
                padding: 1px 4px;
                """
            )
            # END: poprawiony styl przycisku
            button.setCursor(Qt.PointingHandCursor)

            # BEGIN: Nakładanie stylu dla przycisku menu
            apply_component_styles(button, "button")
            # END: Nakładanie stylu dla przycisku menu

            if action == "exit":
                button.clicked.connect(lambda: os._exit(0))
            elif target:
                button.clicked.connect(lambda _, t=target: self.handle_click(t))

            self.layout.addWidget(button)

    def handle_click(self, target_widget):
        if self.callback:
            self.callback(target_widget)
        else:
            print(f"[WARN] Brak funkcji callback dla menu: {target_widget}")

    # BEGIN: Dynamiczne odświeżenie spacingu przycisków
    def odswiez(self):
        self.settings = self.load_settings()
        self.scale = self.settings.get("gui", {}).get("scale_widgets", 1.0)
        self.font_size = self.settings.get("gui", {}).get("font_size", 12)
        self.padding = self.settings.get("gui", {}).get("padding", 0)
        self.spacing = self.settings.get("gui", {}).get("button_spacing", 10)

        self.layout.setSpacing(int(self.spacing))
        self.layout.setContentsMargins(
            self.padding, self.padding, self.padding, self.padding
        )

        while self.layout.count():
            item = self.layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.setParent(None)
                widget.deleteLater()

        self.load_menu_buttons()
        self.update()
    # END: Dynamiczne odświeżenie spacingu przycisków
