# -*- coding: utf-8 -*-
import sys
from PyQt5.QtWidgets import QApplication
from main.okno_glowne import MainWindow

# BEGIN: Uruchamianie aplikacji
def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()
# END: Uruchamianie aplikacji
