# -*- coding: utf-8 -*-
# projekt/main/loader.py

import os
import json
import importlib
from PyQt5.QtWidgets import QWidget

# BEGIN: Funkcja ładująca widżety z widgets.json
def load_widgets(json_path="config/widgets.json"):
    widgets = []

    if not os.path.exists(json_path):
        print(f"[INFO] Brak pliku widgets.json – pomijam ładowanie widżetów.")
        return widgets

    try:
        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        for item in data:
            modulename = item.get("module")
            classname = item.get("class")
            position = item.get("position", "center")

            if not modulename or not classname:
                print(f"[WARN] Nieprawidłowy wpis widgeta: {item}")
                continue

            try:
                module = importlib.import_module(f"widzety.{modulename}")
                widget_class = getattr(module, classname)
                if issubclass(widget_class, QWidget):
                    widgets.append({
                        "instance": widget_class(),
                        "position": position
                    })
                else:
                    print(f"[WARN] Klasa {classname} nie jest QWidgetem.")
            except Exception as e:
                print(f"[ERROR] Błąd ładowania {classname} z {modulename}: {e}")

    except Exception as e:
        print(f"[ERROR] Nie można wczytać widgets.json: {e}")

    return widgets
# END: Funkcja ładująca widżety
