# -*- coding: utf-8 -*-
# projekt/main/okno_glowne.py

import os
import json
import inspect
import importlib
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QScrollArea, QLabel
)
from PyQt5.QtGui import QFontDatabase, QFont, QPixmap, QPalette, QBrush
from PyQt5.QtCore import Qt

from main.loader import load_widgets

# BEGIN: Główne okno aplikacji z pełnym systemem layoutów
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.settings = self.load_settings()
        self.style_overrides = self.load_style_overrides()
        self.scale_widgets = self.settings["gui"].get("scale_widgets", 1.0)
        self.scale_fonts = self.settings["gui"].get("scale_fonts", 1.0)
        self.padding = self.settings["gui"].get("padding", 0)

        self.centralny_widget = None  # <- dla dynamicznej podmiany
        self.init_ui()

    def load_settings(self):
        default_settings = {
            "window": {
                "width": 800,
                "height": 600,
                "resizable": True,
                "fullscreen": False,
                "background_image": ""
            },
            "gui": {
                "font_path": "",
                "font_size": 12,
                "scale_widgets": 1.0,
                "scale_fonts": 1.0,
                "padding": 0
            },
            "components": {}
        }
        try:
            with open("config/settings.json", "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"[WARN] Nie można wczytać settings.json: {e}")
            return default_settings

    def load_style_overrides(self):
        try:
            with open("config/style_overrides.json", "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"[INFO] style_overrides.json niezaładowany: {e}")
            return {}

    def init_ui(self):
        width = self.settings["window"].get("width", 800)
        height = self.settings["window"].get("height", 600)
        if self.settings["window"].get("resizable", True):
            self.resize(width, height)
        else:
            self.setFixedSize(width, height)

        if self.settings["window"].get("fullscreen", False):
            self.showFullScreen()

        bg_path = self.settings["window"].get("background_image", "")
        if os.path.exists(bg_path):
            self.set_background_image(bg_path)

        self.apply_font()

        from core.style_applier import apply_component_styles
        from PyQt5.QtWidgets import QWidget

        def apply_styles_recursively(w, theme_type):
            apply_component_styles(w, theme_type)
            for child in w.findChildren(QWidget):
                apply_styles_recursively(child, theme_type)

        central_widget = QWidget()
        outer_layout = QVBoxLayout(central_widget)
        outer_layout.setContentsMargins(self.padding, self.padding, self.padding, self.padding)
        outer_layout.setSpacing(int(10 * self.scale_widgets))

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)

        scroll_container = QWidget()
        main_layout = QVBoxLayout(scroll_container)

        layout_top = QHBoxLayout()
        layout_center_row = QHBoxLayout()
        layout_bottom = QHBoxLayout()
        self.centralny_layout = QVBoxLayout()
        layout_center_row.addLayout(self.centralny_layout)

        for item in load_widgets():
            widget = item["instance"]
            position = item.get("position", "center").lower()
            widget_id = type(widget).__name__

            # Jeśli widżet ma być w centrum — pomijamy, będzie ładowany dynamicznie
            if position == "center":
                continue

            style = self.style_overrides.get(widget_id, {}).get("style")
            if style:
                widget.setStyleSheet(style)

            if hasattr(widget, "set_callback") and callable(getattr(widget, "set_callback", None)):
                widget.set_callback(self.otworz_widzet_z_menu)

            if position == "top":
                layout_top.addWidget(widget)
            elif position == "bottom":
                layout_bottom.addWidget(widget)
            else:
                layout_center_row.addWidget(widget)

            style_type = item.get("style_type", "")
            if style_type:
                try:
                    apply_styles_recursively(widget, style_type)
                except Exception as e:
                    print(f"[WARN] Nie udało się zastosować stylu komponentu '{style_type}': {e}")

        main_layout.addLayout(layout_top)
        main_layout.addLayout(layout_center_row)
        main_layout.addLayout(layout_bottom)

        scroll_area.setWidget(scroll_container)
        outer_layout.addWidget(scroll_area)

        self.setCentralWidget(central_widget)
        self.setWindowTitle("Dynamiczne Okno Główne")


    def set_background_image(self, image_path):
        pixmap = QPixmap(image_path)
        if not pixmap.isNull():
            palette = QPalette()
            scaled_pixmap = pixmap.scaled(
                self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation
            )
            palette.setBrush(QPalette.Window, QBrush(scaled_pixmap))
            self.setPalette(palette)
            self.setAutoFillBackground(True)
        else:
            print(f"[WARN] Nie można załadować tła: {image_path}")

    def apply_font(self):
        font_path = self.settings["gui"].get("font_path", "")
        font_size = int(self.settings["gui"].get("font_size", 12) * self.scale_fonts)

        if font_path and os.path.exists(font_path):
            font_id = QFontDatabase.addApplicationFont(font_path)
            families = QFontDatabase.applicationFontFamilies(font_id)
            if families:
                font = QFont(families[0], font_size)
                QApplication.setFont(font)
                return

        QApplication.setFont(QFont("Arial", font_size))

    # BEGIN: Rozszerzenie o dodatkowe funkcje pomocnicze

    def get_setting(self, path, default=None):
        """Bezpieczne pobieranie ustawień przez ścieżkę kropkowaną, np. 'gui.scale_fonts'"""
        keys = path.split(".")
        result = self.settings
        try:
            for key in keys:
                result = result.get(key, {})
            if isinstance(result, dict):
                return default
            return result
        except Exception as e:
            print(f"[WARN] Błąd pobierania ustawienia {path}: {e}")
            return default

    def zapisz_ustawienia(self):
        """Placeholder – do użycia przez widget ustawień"""
        pass

    def otworz_okno_opcji(self):
        from widzety.widget_ustawienia.panel_theme import PanelTheme
        nowy_widget = PanelTheme(self.settings)

        if self.centralny_widget:
            self.centralny_layout.removeWidget(self.centralny_widget)
            self.centralny_widget.setParent(None)
            self.centralny_widget.deleteLater()

        self.centralny_widget = nowy_widget
        self.centralny_layout.addWidget(self.centralny_widget)

    # END: Rozszerzenie o dodatkowe funkcje pomocnicze

    # BEGIN: obsługa kliknięcia w menu bocznym
    def otworz_widzet_z_menu(self, identyfikator):
        try:
            if identyfikator == "widget_ustawienia":
                from widzety.widget_ustawienia import WidgetUstawienia
                nowy_widget = WidgetUstawienia()
            elif identyfikator == "widget_zarzadzanie":
                from widzety.widget_zarzadzanie import Widget
                nowy_widget = Widget(self.settings)
            else:
                # IMPORT DYNAMICZNY – tylko dla pozostałych
                pelna_sciezka = f"widzety.{identyfikator}" if not identyfikator.startswith("widzety.") else identyfikator
                module = importlib.import_module(pelna_sciezka)

                if not hasattr(module, "Widget") or not inspect.isclass(module.Widget):
                    print(f"[ERROR] Modul '{pelna_sciezka}' nie zawiera klasy 'Widget'")
                    return

                nowy_widget = module.Widget(self.settings)

            # USUWANIE STAREGO WIDŻETU
            if self.centralny_widget:
                self.centralny_layout.removeWidget(self.centralny_widget)
                self.centralny_widget.setParent(None)
                self.centralny_widget.deleteLater()

            # DODAWANIE NOWEGO
            self.centralny_widget = nowy_widget
            self.centralny_layout.addWidget(self.centralny_widget)

        except Exception as e:
            print(f"[ERROR] Nie udało się załadować widżetu '{identyfikator}': {e}")
    # END: Przełączanie widżetów centralnych dynamicznie



# END: Główne okno aplikacji z pełnym systemem layoutów
