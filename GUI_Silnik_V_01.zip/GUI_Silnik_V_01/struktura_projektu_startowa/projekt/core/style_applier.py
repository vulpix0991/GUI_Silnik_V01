# -*- coding: utf-8 -*-
# core/style_applier.py

from PyQt5.QtWidgets import QPushButton, QLineEdit, QLabel
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt
import os
from widzety.widget_ustawienia.controller import controller

def apply_component_styles(widget, component_type):
    """Nakłada style (np. tło, czcionkę, rozmiar, marginesy, padding) na widget zgodnie z settings.json"""

    settings = controller.settings.get("components", {})
    comp = settings.get(component_type, {})

    style_parts = []

    # Styl graficzny (background-image)
    background = comp.get("background", "")
    if background and os.path.exists(background):
        style_parts.append(f"background-image: url('{background}');")
        style_parts.append("background-repeat: no-repeat;")
        style_parts.append("background-position: center;")

    # Czcionka
    font_size = comp.get("font_size")
    if font_size:
        style_parts.append(f"font-size: {font_size}pt;")

    # Margin
    margin = comp.get("margin")
    if isinstance(margin, int):
        style_parts.append(f"margin: {margin}px;")
    elif isinstance(margin, (list, tuple)) and len(margin) == 4:
        style_parts.append(f"margin: {margin[0]}px {margin[1]}px {margin[2]}px {margin[3]}px;")

    # Padding
    padding = comp.get("padding")
    if isinstance(padding, int):
        style_parts.append(f"padding: {padding}px;")
    elif isinstance(padding, (list, tuple)) and len(padding) == 4:
        style_parts.append(f"padding: {padding[0]}px {padding[1]}px {padding[2]}px {padding[3]}px;")

    # Rozmiar (dla przycisków)
    width = comp.get("width")
    height = comp.get("height")
    if width:
        widget.setFixedWidth(width)
    if height:
        widget.setFixedHeight(height)

    # Zastosowanie stylu
    if style_parts:
        widget.setStyleSheet(" ".join(style_parts))

    # Usunięcie wewnętrznych marginesów dla przycisków
    if isinstance(widget, QPushButton):
        widget.setContentsMargins(0, 0, 0, 0)
